Name:		Mehezabin Ahamed
Student NO.: 	8524484
Course Code:	ITI1121
Assignment 2